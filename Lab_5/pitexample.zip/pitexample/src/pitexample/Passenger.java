package pitexample;

public class Passenger {

    private int age;

    public Passenger(int age) {
        this.age = age;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

}

